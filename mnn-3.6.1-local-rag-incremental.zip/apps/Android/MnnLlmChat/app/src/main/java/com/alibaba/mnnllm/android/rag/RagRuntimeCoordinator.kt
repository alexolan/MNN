package com.alibaba.mnnllm.android.rag

import android.content.Context
import android.net.Uri
import java.io.Closeable
import java.io.File

/**
 * Owns the application-level RAG runtime and connects model validation,
 * parsing, indexing, retrieval, and prompt augmentation.
 */
class RagRuntimeCoordinator(
    context: Context,
    private val database: RagDatabase = RagDatabase(context.applicationContext)
) : Closeable {
    private val appContext = context.applicationContext
    private val preferences = appContext.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
    private var runtime: Runtime? = null

    init {
        restoreConfiguredModel()
    }

    @Synchronized
    fun configure(modelBundleDirectory: File, manifestFile: File): RuntimeInfo {
        return configureInternal(modelBundleDirectory, manifestFile, persist = true)
    }

    private fun configureInternal(
        modelBundleDirectory: File,
        manifestFile: File,
        persist: Boolean
    ): RuntimeInfo {
        closeRuntime()
        val validated = ModelManifestValidator().validate(modelBundleDirectory, manifestFile)
        val model = validated.embeddingModel
        val dimensions = embeddingDimensions(model)
        val configFile = embeddingConfigFile(validated, model)
        val engine = MnnEmbeddingEngine(configFile, dimensions)
        val vectorDirectory = File(appContext.filesDir, "rag/vectors").apply { mkdirs() }
        val vectorStore = VectorStore(
            File(vectorDirectory, "${validated.manifestHash}.bin"),
            dimensions,
            validated.manifestHash
        )
        val chunker = DeterministicChunker(
            TokenCounter { text -> text.codePointCount(0, text.length).coerceAtLeast(1) },
            ChunkingConfig(maxTokens = 512, overlapTokens = 64)
        )
        val orchestrator = IndexingOrchestrator(database, chunker)
        val pipeline = VectorIndexingPipeline(database, vectorStore, engine, orchestrator)
        val retriever = RagRetriever(database, vectorStore, engine)
        val assembler = RagContextAssembler()

        runtime = Runtime(
            manifestHash = validated.manifestHash,
            dimensions = dimensions,
            engine = engine,
            vectorStore = vectorStore,
            orchestrator = orchestrator,
            pipeline = pipeline,
            retriever = retriever,
            assembler = assembler
        )
        if (persist) {
            preferences.edit()
                .putString(KEY_MODEL_BUNDLE_PATH, modelBundleDirectory.canonicalPath)
                .putString(KEY_MODEL_MANIFEST_PATH, manifestFile.canonicalPath)
                .apply()
        }
        return RuntimeInfo(validated.manifestHash, dimensions, model.id)
    }

    private fun restoreConfiguredModel() {
        val bundlePath = preferences.getString(KEY_MODEL_BUNDLE_PATH, null) ?: return
        val manifestPath = preferences.getString(KEY_MODEL_MANIFEST_PATH, null) ?: return
        val bundleDirectory = File(bundlePath)
        val manifestFile = File(manifestPath)
        runCatching {
            configureInternal(bundleDirectory, manifestFile, persist = false)
        }.onFailure {
            closeRuntime()
            preferences.edit()
                .remove(KEY_MODEL_BUNDLE_PATH)
                .remove(KEY_MODEL_MANIFEST_PATH)
                .apply()
        }
    }

    @Synchronized
    fun promptProvider(knowledgeBaseId: Long): RagPromptProvider? {
        if (knowledgeBaseId <= 0L) return null
        val active = runtime ?: return null
        return RagPromptProvider { question ->
            val hits = active.retriever.retrieve(knowledgeBaseId, question)
            active.assembler.assemble(question, hits)
        }
    }

    @Synchronized
    fun indexImported(result: DocumentImporter.ImportResult.Imported): VectorIndexingPipeline.Result {
        return indexDocument(result.document)
    }

    @Synchronized
    fun indexDocument(document: RagDocument): VectorIndexingPipeline.Result {
        val active = checkNotNull(runtime) { "RAG embedding model is not configured" }
        val parser = parserFor(document)
        val prepared = active.orchestrator.prepareForEmbedding(
            document = document,
            parse = {
                appContext.contentResolver.openInputStream(Uri.parse(document.sourceUri))?.use(parser::parse)
                    ?: error("Unable to open imported document")
            }
        )
        if (prepared is IndexingOrchestrator.IndexingResult.Failed) {
            return VectorIndexingPipeline.Result.Failed(prepared.reason, prepared.cause)
        }
        return active.pipeline.indexDocument(document.id)
    }

    fun isConfigured(): Boolean = synchronized(this) { runtime != null }

    @Synchronized
    override fun close() {
        closeRuntime()
        database.close()
    }

    private fun closeRuntime() {
        val active = runtime ?: return
        runtime = null
        active.vectorStore.close()
        active.engine.close()
    }

    private fun parserFor(document: RagDocument): DocumentParser {
        val extension = document.displayName.substringAfterLast('.', "").lowercase()
        return when {
            extension in setOf("md", "markdown") || document.mimeType == "text/markdown" ->
                MarkdownDocumentParser()
            extension == "docx" ||
                document.mimeType == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ->
                DocxDocumentParser()
            extension == "txt" || document.mimeType == "text/plain" -> TextDocumentParser()
            else -> error("No indexing parser is available for ${document.displayName}")
        }
    }

    private fun embeddingDimensions(model: RagModelDefinition): Int {
        val output = model.outputs.single { it.name == "sentence_embeddings" }
        return output.shape.lastOrNull()?.takeIf { it > 0 }
            ?: error("Embedding output dimensions are missing from the manifest")
    }

    private fun embeddingConfigFile(
        bundle: ModelManifestValidator.ValidatedModelBundle,
        model: RagModelDefinition
    ): File {
        val configured = model.options[OPTION_CONFIG_PATH]
        if (!configured.isNullOrBlank()) {
            val candidate = File(bundle.directory, configured).canonicalFile
            require(candidate.isFile && candidate.toPath().startsWith(bundle.directory.canonicalFile.toPath())) {
                "Embedding config path is invalid"
            }
            return candidate
        }
        return bundle.files.firstOrNull {
            it.modelId == model.id && it.file.extension.equals("json", ignoreCase = true)
        }?.file ?: error("Embedding model config JSON is not declared")
    }

    data class RuntimeInfo(
        val manifestHash: String,
        val dimensions: Int,
        val embeddingModelId: String
    )

    private data class Runtime(
        val manifestHash: String,
        val dimensions: Int,
        val engine: EmbeddingEngine,
        val vectorStore: VectorStore,
        val orchestrator: IndexingOrchestrator,
        val pipeline: VectorIndexingPipeline,
        val retriever: RagRetriever,
        val assembler: RagContextAssembler
    )

    companion object {
        const val OPTION_CONFIG_PATH = "configPath"
        private const val PREFERENCES = "rag_runtime"
        private const val KEY_MODEL_BUNDLE_PATH = "model_bundle_path"
        private const val KEY_MODEL_MANIFEST_PATH = "model_manifest_path"
    }
}
